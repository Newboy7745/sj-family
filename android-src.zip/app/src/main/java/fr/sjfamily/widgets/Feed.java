package fr.sjfamily.widgets;

import android.graphics.Color;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Flux publié par l'application SJ Family (document widgets/{jeton}). */
public final class Feed {
    public final JSONObject o;
    public final LocalDate start;
    public final int ht;
    public final int mid;
    public final String app;

    public Feed(String json) throws JSONException {
        o = new JSONObject(json);
        start = LocalDate.parse(o.getString("start"));
        ht = toMin(o.optString("ht", "18:30"));
        mid = toMin(o.optString("mid", "14:00"));
        app = o.optString("app", "https://newboy7745.github.io/sj-family/");
    }

    public static int toMin(String t) {
        try {
            String[] p = t.split(":");
            return Integer.parseInt(p[0].trim()) * 60 + Integer.parseInt(p[1].trim());
        } catch (Exception e) {
            return 18 * 60 + 30;
        }
    }

    public String familyName() {
        return o.optString("family", "SJ Family");
    }

    public List<JSONObject> children() {
        List<JSONObject> r = new ArrayList<>();
        JSONArray a = o.optJSONArray("children");
        if (a != null) {
            for (int i = 0; i < a.length(); i++) {
                JSONObject c = a.optJSONObject(i);
                if (c != null) r.add(c);
            }
        }
        return r;
    }

    /** sel = "*" pour tous les enfants, sinon l'identifiant d'un enfant. */
    public List<JSONObject> kids(String sel) {
        List<JSONObject> all = children();
        if (sel == null || "*".equals(sel)) return all;
        List<JSONObject> r = new ArrayList<>();
        for (JSONObject c : all) if (sel.equals(c.optString("id"))) r.add(c);
        return r.isEmpty() ? all : r;
    }

    public static Set<String> ids(List<JSONObject> kids) {
        Set<String> s = new HashSet<>();
        for (JSONObject k : kids) s.add(k.optString("id"));
        return s;
    }

    public String label(List<JSONObject> kids) {
        if (kids.size() > 2) return "Les enfants";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < kids.size(); i++) {
            if (i > 0) b.append(" & ");
            b.append(kids.get(i).optString("name"));
        }
        return b.toString();
    }

    public String kidNames(JSONArray k) {
        if (k == null) return "";
        StringBuilder b = new StringBuilder();
        for (JSONObject c : children()) {
            for (int j = 0; j < k.length(); j++) {
                if (c.optString("id").equals(k.optString(j))) {
                    if (b.length() > 0) b.append(" & ");
                    b.append(c.optString("name"));
                }
            }
        }
        return b.toString();
    }

    public char code(JSONObject child, LocalDate d) {
        long i = ChronoUnit.DAYS.between(start, d);
        String days = child.optString("days", "");
        if (i < 0 || i >= days.length()) return '.';
        return days.charAt((int) i);
    }

    public static String first(char c) {
        if (c == 'A' || c == 'a' || c == 'X') return "A";
        if (c == 'B' || c == 'b' || c == 'Y') return "B";
        return null;
    }

    public static String last(char c) {
        if (c == 'A' || c == 'a' || c == 'Y') return "A";
        if (c == 'B' || c == 'b' || c == 'X') return "B";
        return null;
    }

    static String hhmm(int m) {
        return String.format(java.util.Locale.FRANCE, "%02d:%02d", m / 60, m % 60);
    }

    public String middayTime() {
        return hhmm(mid);
    }

    /** Heure du relais du soir du jour d (horaire convenu si un échange l'a modifié). */
    public String eveningTime(JSONObject child, LocalDate d) {
        return hhmm(evening(child, d));
    }

    private int evening(JSONObject child, LocalDate d) {
        JSONArray hs = o.optJSONArray("handovers");
        String ds = d.toString();
        String id = child.optString("id");
        if (hs != null) {
            for (int i = 0; i < hs.length(); i++) {
                JSONObject h = hs.optJSONObject(i);
                if (h == null || !ds.equals(h.optString("d")) || h.optInt("m", 0) == 1) continue;
                JSONArray k = h.optJSONArray("k");
                if (k == null) continue;
                for (int j = 0; j < k.length(); j++) if (id.equals(k.optString(j))) return toMin(h.optString("t"));
            }
        }
        return ht;
    }

    /** Parent ("A" ou "B") qui a l'enfant à cet instant ; règle : la garde du jour J commence la veille à 18h30. */
    public String presence(JSONObject child, LocalDateTime now) {
        LocalDate d = now.toLocalDate();
        int m = now.getHour() * 60 + now.getMinute();
        if (m >= evening(child, d)) return first(code(child, d.plusDays(1)));
        char c = code(child, d);
        if (c == 'X') return m < mid ? "A" : "B";
        if (c == 'Y') return m < mid ? "B" : "A";
        return first(c);
    }

    public JSONObject parent(String p) {
        JSONObject ps = o.optJSONObject("parents");
        return ps == null || p == null ? null : ps.optJSONObject(p);
    }

    public String pShort(String p) {
        JSONObject x = parent(p);
        if (x == null) return "—";
        String s = x.optString("short", "");
        return s.isEmpty() ? x.optString("name", "—") : s;
    }

    public String pName(String p) {
        JSONObject x = parent(p);
        return x == null ? "—" : x.optString("name", "—");
    }

    public int pColor(String p) {
        String def = "A".equals(p) ? "#9DC3E6" : "#F8CBAD";
        JSONObject x = parent(p);
        return parse(x == null ? def : x.optString("color", def), def);
    }

    static int parse(String hex, String def) {
        try {
            return Color.parseColor(hex);
        } catch (Exception e) {
            return Color.parseColor(def);
        }
    }

    public int colorFor(char c) {
        switch (c) {
            case 'A': return pColor("A");
            case 'B': return pColor("B");
            case 'a': return lighten(pColor("A"), 0.55f);
            case 'b': return lighten(pColor("B"), 0.55f);
            case 'X':
            case 'Y': return blend(pColor("A"), pColor("B"));
            default: return 0x26FFFFFF;
        }
    }

    static int lighten(int c, float k) {
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        r = (int) (r + (255 - r) * k);
        g = (int) (g + (255 - g) * k);
        b = (int) (b + (255 - b) * k);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    static int mix(int a, int b, float k) {
        int r = (int) (((a >> 16) & 255) * (1 - k) + ((b >> 16) & 255) * k);
        int g = (int) (((a >> 8) & 255) * (1 - k) + ((b >> 8) & 255) * k);
        int bl = (int) ((a & 255) * (1 - k) + (b & 255) * k);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    static int blend(int a, int b) {
        int r = (((a >> 16) & 255) + ((b >> 16) & 255)) / 2;
        int g = (((a >> 8) & 255) + ((b >> 8) & 255)) / 2;
        int bl = ((a & 255) + (b & 255)) / 2;
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    public static LocalDateTime at(JSONObject h) {
        try {
            int m = toMin(h.optString("t"));
            return LocalDate.parse(h.optString("d")).atTime(m / 60, m % 60);
        } catch (Exception e) {
            return null;
        }
    }

    static boolean intersects(JSONArray k, Set<String> ids) {
        if (k == null || k.length() == 0) return true;
        for (int j = 0; j < k.length(); j++) if (ids.contains(k.optString(j))) return true;
        return false;
    }

    /** Relais à venir pour au moins un des enfants. */
    public List<JSONObject> nextHandovers(Set<String> kidIds, LocalDateTime now, int max) {
        List<JSONObject> r = new ArrayList<>();
        JSONArray hs = o.optJSONArray("handovers");
        if (hs == null) return r;
        for (int i = 0; i < hs.length() && r.size() < max; i++) {
            JSONObject h = hs.optJSONObject(i);
            if (h == null) continue;
            LocalDateTime t = at(h);
            if (t == null || !t.isAfter(now)) continue;
            if (intersects(h.optJSONArray("k"), kidIds)) r.add(h);
        }
        return r;
    }

    public boolean hasHandover(Set<String> kidIds, LocalDate d) {
        JSONArray hs = o.optJSONArray("handovers");
        if (hs == null) return false;
        String ds = d.toString();
        for (int i = 0; i < hs.length(); i++) {
            JSONObject h = hs.optJSONObject(i);
            if (h != null && ds.equals(h.optString("d")) && intersects(h.optJSONArray("k"), kidIds)) return true;
        }
        return false;
    }

    public List<JSONObject> events(Set<String> kidIds, LocalDate from, int max) {
        List<JSONObject> r = new ArrayList<>();
        JSONArray a = o.optJSONArray("events");
        if (a == null) return r;
        String f = from.toString();
        for (int i = 0; i < a.length() && r.size() < max; i++) {
            JSONObject e = a.optJSONObject(i);
            if (e == null || e.optString("d").compareTo(f) < 0) continue;
            if (intersects(e.optJSONArray("k"), kidIds)) r.add(e);
        }
        return r;
    }

    public List<JSONObject> tasks(Set<String> kidIds, int max) {
        List<JSONObject> r = new ArrayList<>();
        JSONArray a = o.optJSONArray("tasks");
        if (a == null) return r;
        for (int i = 0; i < a.length() && r.size() < max; i++) {
            JSONObject t = a.optJSONObject(i);
            if (t != null && intersects(t.optJSONArray("k"), kidIds)) r.add(t);
        }
        return r;
    }

    public JSONObject lastNote(Set<String> kidIds) {
        JSONArray a = o.optJSONArray("notes");
        if (a == null) return null;
        for (int i = 0; i < a.length(); i++) {
            JSONObject n = a.optJSONObject(i);
            if (n != null && intersects(n.optJSONArray("k"), kidIds)) return n;
        }
        return null;
    }

    public String off(LocalDate d) {
        JSONObject off = o.optJSONObject("off");
        if (off == null) return null;
        String s = off.optString(d.toString(), "");
        return s.isEmpty() ? null : s;
    }
}
