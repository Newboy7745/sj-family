package fr.sjfamily.widgets;

/** Widget « Programme ». */
public class ProgrammeWidget extends BaseWidget {
}
