package fr.sjfamily.widgets;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

/** Rappels locaux avant chaque relais (aucun serveur nécessaire). */
final class Reminders {
    static final String CHANNEL = "relais";
    static final int BASE = 700;
    static final int MAX = 6;

    private Reminders() { }

    static void channel(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Rappels de relais", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Rappel avant chaque passage des enfants d'un parent à l'autre");
        nm.createNotificationChannel(ch);
    }

    static void schedule(Context c) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (am == null) return;
        for (int i = 0; i < MAX; i++) {
            PendingIntent old = PendingIntent.getBroadcast(c, BASE + i, new Intent(c, AlarmReceiver.class),
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (old != null) {
                am.cancel(old);
                old.cancel();
            }
        }
        int before = Store.remind(c);
        Feed f = Store.feed(c);
        if (before < 0 || f == null) return;
        LocalDateTime now = LocalDateTime.now();
        List<JSONObject> hs = f.nextHandovers(Feed.ids(f.children()), now, MAX);
        int n = 0;
        for (JSONObject h : hs) {
            LocalDateTime at = Feed.at(h);
            if (at == null) continue;
            LocalDateTime when = at.minusMinutes(before);
            if (!when.isAfter(now)) continue;
            String title = "🔁 Relais " + Fmt.rel(at.toLocalDate(), when.toLocalDate()) + " à " + Fmt.time(h.optString("t"));
            String place = h.optString("p", "");
            String text = f.kidNames(h.optJSONArray("k")) + " : " + f.pName(h.optString("f")) + " → " + f.pName(h.optString("to"))
                    + (place.isEmpty() ? "" : " — " + place);
            Intent it = new Intent(c, AlarmReceiver.class)
                    .putExtra("title", title).putExtra("text", text).putExtra("url", f.app + "#/agenda")
                    .putExtra("id", BASE + n);
            PendingIntent pi = PendingIntent.getBroadcast(c, BASE + n, it, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            long ms = when.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi);
            n++;
        }
    }

    static void notify(Context c, int id, String title, String text, String url) {
        channel(c);
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        Intent open = url == null || url.isEmpty() ? new Intent(c, MainActivity.class) : new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(c, id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        nm.notify(id, n);
    }

    static LocalDate today() {
        return LocalDate.now();
    }
}
