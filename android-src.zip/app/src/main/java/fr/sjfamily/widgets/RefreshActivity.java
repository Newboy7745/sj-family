package fr.sjfamily.widgets;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;

/**
 * Bouton ⟳ des widgets : le téléchargement se fait au premier plan (une activité invisible),
 * car Samsung coupe souvent internet aux applis en arrière-plan (« UnknownHostException »).
 */
public class RefreshActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final android.content.Context app = getApplicationContext();
        Widgets.refreshing(app, true);
        new Thread(() -> {
            String err = Store.fetch(app);
            Widgets.refreshing(app, false);
            Reminders.schedule(app);
            final String msg = err != null ? "SJ Family : " + err : "SJ Family : planning à jour ✓" + Store.updateHint(app);
            runOnUiThread(() -> {
                Toast.makeText(app, msg, Toast.LENGTH_SHORT).show();
                finish();
                overridePendingTransition(0, 0);
            });
        }).start();
    }
}
