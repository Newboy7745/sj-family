package fr.sjfamily.widgets;

/** Widget « Semaine ». */
public class SemaineWidget extends BaseWidget {
}
