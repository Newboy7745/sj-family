package fr.sjfamily.widgets;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Affiche un rappel de relais ; reprogramme les rappels après un redémarrage du téléphone. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            Reminders.schedule(context);
            Widgets.updateAll(context);
            return;
        }
        String title = intent.getStringExtra("title");
        if (title == null) return;
        Reminders.notify(context, intent.getIntExtra("id", 700), title, intent.getStringExtra("text"), intent.getStringExtra("url"));
        Widgets.updateAll(context);
    }
}
