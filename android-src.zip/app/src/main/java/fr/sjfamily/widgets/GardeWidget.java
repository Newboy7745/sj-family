package fr.sjfamily.widgets;

/** Widget « Garde ». */
public class GardeWidget extends BaseWidget {
}
