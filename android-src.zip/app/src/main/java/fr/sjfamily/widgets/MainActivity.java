package fr.sjfamily.widgets;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Date;

/** Écran de l'app : connexion au cercle, rappels, aide pour ajouter les widgets. */
public class MainActivity extends Activity {
    static final int[] REMIND = {-1, 30, 60, 120, 240, 1440};
    static final String[] REMIND_L = {"Aucun rappel", "30 min avant", "1 h avant", "2 h avant", "4 h avant", "La veille (24 h avant)"};

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Reminders.channel(this);
        handle(getIntent());
        askNotifications();
        build();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handle(intent);
        build();
    }

    private void handle(Intent i) {
        Uri u = i == null ? null : i.getData();
        if (u != null && "sjfamily".equals(u.getScheme())) {
            String t = u.getQueryParameter("t");
            if (t != null && !t.trim().isEmpty()) {
                Store.setToken(this, t);
                refresh(true);
            }
        }
    }

    private void askNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
    }

    private void refresh(final boolean toast) {
        new Thread(() -> {
            final String err = Store.fetch(getApplicationContext());
            Widgets.updateAll(getApplicationContext());
            Reminders.schedule(getApplicationContext());
            runOnUiThread(() -> {
                if (toast) Toast.makeText(this, err == null ? "Widgets à jour ✓" : err, Toast.LENGTH_LONG).show();
                build();
            });
        }).start();
    }

    private void build() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout root = UI.column(this);
        sv.addView(root);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        head.addView(logo, new LinearLayout.LayoutParams(UI.dp(this, 64), UI.dp(this, 64)));
        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        ht.setPadding(UI.dp(this, 14), 0, 0, 0);
        ht.addView(UI.title(this, "SJ Widgets"));
        ht.addView(UI.muted(this, "Les widgets de SJ Family pour votre écran d'accueil"));
        head.addView(ht);
        root.addView(head);

        Feed f = Store.feed(this);
        LinearLayout st = UI.card(this);
        if (Store.token(this) == null) {
            st.addView(UI.text(this, "🔌 Pas encore connecté", 18));
            st.addView(UI.muted(this, "Dans SJ Family : Accueil › Widgets › « Connecter mes widgets ». Ou collez le code de connexion ci-dessous."));
        } else if (f == null) {
            st.addView(UI.text(this, "⏳ Connexion en cours…", 18));
            st.addView(UI.muted(this, "Vérifiez votre connexion internet puis touchez « Actualiser »."));
        } else {
            st.addView(UI.text(this, "✅ Connecté : " + f.familyName(), 18));
            StringBuilder kids = new StringBuilder();
            for (int i = 0; i < f.children().size(); i++) { if (i > 0) kids.append(", "); kids.append(f.children().get(i).optString("name")); }
            st.addView(UI.muted(this, "Enfants : " + kids + "\nDernière mise à jour : "
                    + DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date(Store.feedAt(this)))
                    + "\nWidgets installés : " + Widgets.count(this) + Widgets.sizes(this)));
        }
        root.addView(st);

        LinearLayout co = UI.card(this);
        co.addView(UI.text(this, "🔑 Code de connexion", 17));
        final EditText code = UI.input(this, "Collez le code copié depuis SJ Family");
        if (Store.token(this) != null) code.setText(Store.token(this));
        co.addView(code);
        Button connect = UI.button(this, "Connecter", UI.NAVY);
        connect.setOnClickListener(v -> {
            String t = code.getText().toString().trim();
            if (t.length() < 10) { Toast.makeText(this, "Code invalide", Toast.LENGTH_SHORT).show(); return; }
            Store.setToken(this, t);
            refresh(true);
        });
        co.addView(connect);
        Button upd = UI.button(this, "Actualiser maintenant", UI.CORAL);
        upd.setOnClickListener(v -> refresh(true));
        co.addView(upd);
        root.addView(co);

        LinearLayout re = UI.card(this);
        re.addView(UI.text(this, "🔔 Rappel avant chaque relais", 17));
        Spinner sp = new Spinner(this);
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, REMIND_L));
        int cur = Store.remind(this), sel = 3;
        for (int i = 0; i < REMIND.length; i++) if (REMIND[i] == cur) sel = i;
        sp.setSelection(sel, false);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (Store.remind(MainActivity.this) == REMIND[position]) return;
                Store.setRemind(MainActivity.this, REMIND[position]);
                Reminders.schedule(MainActivity.this);
                Toast.makeText(MainActivity.this, "Rappel : " + REMIND_L[position], Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
        re.addView(sp);
        Button test = UI.button(this, "Tester une notification", UI.NAVY);
        test.setOnClickListener(v -> Reminders.notify(this, 799, "✅ SJ Widgets", "Les rappels de relais fonctionnent sur ce téléphone.", null));
        re.addView(test);
        root.addView(re);

        LinearLayout help = UI.card(this);
        help.addView(UI.text(this, "📱 Ajouter un widget", 17));
        help.addView(UI.muted(this, "1. Appui long sur un espace vide de l'écran d'accueil\n2. « Widgets » › « SJ Widgets »\n3. Choisissez : Garde du jour (2×2), Semaine (4×2), Mois (4×4), Pleine page (à étirer sur tout l'écran) ou Programme (4×2)\n4. Sélectionnez l'enfant (ou « Tous les enfants »)\n5. ‹ › : jour, semaine ou mois précédent/suivant · touchez une case pour ouvrir ce jour\n\nPour changer d'enfant ou la largeur plus tard : appui long sur le widget › Paramètres (« Bord à bord » = aussi large que le calendrier Samsung)."));
        Button open = UI.button(this, "Ouvrir SJ Family", UI.NAVY);
        final String url = f != null ? f.app : "https://newboy7745.github.io/sj-family/";
        open.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))));
        help.addView(open);
        root.addView(help);

        TextView ver = UI.muted(this, "SJ Widgets " + versionName());
        ver.setGravity(Gravity.CENTER);
        root.addView(ver);
        setContentView(sv);
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }
}
