package fr.sjfamily.widgets;

/** Widget « Mois ». */
public class MoisWidget extends BaseWidget {
}
