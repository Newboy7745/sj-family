package fr.sjfamily.widgets;

/** Widget « Pleine page » : le mois en grand, à étirer sur tout l'écran d'accueil. */
public class FullWidget extends BaseWidget {
}
