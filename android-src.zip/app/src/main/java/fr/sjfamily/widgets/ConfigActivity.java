package fr.sjfamily.widgets;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Toast;

import org.json.JSONObject;

/** Choix de l'enfant affiché par un widget (à l'ajout ou via « Paramètres » du widget). */
public class ConfigActivity extends Activity {
    private int widgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private boolean loading = false;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setResult(RESULT_CANCELED);
        Bundle ex = getIntent().getExtras();
        if (ex != null) widgetId = ex.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }
        build();
    }

    private void build() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = UI.column(this);
        sv.addView(root);
        root.addView(UI.title(this, "Quel enfant afficher ?"));
        if (Store.token(this) == null) {
            root.addView(UI.muted(this, "Connectez d'abord SJ Widgets à votre cercle : dans SJ Family › Widgets, touchez « Copier le code de connexion » puis collez-le ici."));
            final EditText et = UI.input(this, "Code de connexion");
            root.addView(et);
            Button b = UI.button(this, "Connecter", UI.NAVY);
            b.setOnClickListener(v -> {
                String t = et.getText().toString().trim();
                if (t.length() < 10) { Toast.makeText(this, "Code invalide", Toast.LENGTH_SHORT).show(); return; }
                Store.setToken(this, t);
                load();
            });
            root.addView(b);
            setContentView(sv);
            return;
        }
        Feed f = Store.feed(this);
        if (f == null) {
            root.addView(UI.muted(this, "Chargement du planning…"));
            setContentView(sv);
            load();
            return;
        }
        final RadioGroup g = new RadioGroup(this);
        g.setPadding(0, UI.dp(this, 10), 0, 0);
        String cur = Store.child(this, widgetId);
        g.addView(radio("👪 Tous les enfants", "*", "*".equals(cur)));
        for (JSONObject k : f.children()) {
            String id = k.optString("id");
            g.addView(radio(k.optString("emoji", "🧒") + " " + k.optString("name"), id, id.equals(cur)));
        }
        if (g.getCheckedRadioButtonId() == -1 && g.getChildCount() > 0) ((RadioButton) g.getChildAt(0)).setChecked(true);
        root.addView(g);
        final RadioGroup w = new RadioGroup(this);
        if (Build.VERSION.SDK_INT >= 31) {
            root.addView(UI.title(this, "Largeur du widget"));
            root.addView(UI.muted(this, "Si le widget reste plus étroit que les autres (calendrier Samsung…), choisissez « Bord à bord ». Si ses bords sont coupés, revenez à « Large » ou « Standard »."));
            int e = Store.edge(this, widgetId);
            w.addView(radio("▭ Standard", "0", e == 0));
            w.addView(radio("▬ Large", "1", e == 1));
            w.addView(radio("⬛ Bord à bord", "2", e == 2));
            root.addView(w);
        }
        Button ok = UI.button(this, "Valider", UI.CORAL);
        ok.setOnClickListener(v -> {
            RadioButton rb = g.findViewById(g.getCheckedRadioButtonId());
            String child = rb == null ? "*" : String.valueOf(rb.getTag());
            Store.setChild(this, widgetId, child);
            RadioButton wb = w.findViewById(w.getCheckedRadioButtonId());
            if (wb != null) Store.setEdge(this, widgetId, Integer.parseInt(String.valueOf(wb.getTag())));
            AppWidgetManager m = AppWidgetManager.getInstance(this);
            Widgets.render(this, m, widgetId, typeOf(m));
            Reminders.schedule(this);
            setResult(RESULT_OK, new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId));
            finish();
        });
        root.addView(ok);
        setContentView(sv);
    }

    private RadioButton radio(String label, String tag, boolean checked) {
        RadioButton r = new RadioButton(this);
        r.setId(View.generateViewId());
        r.setText(label);
        r.setTag(tag);
        r.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        r.setPadding(UI.dp(this, 8), UI.dp(this, 12), 0, UI.dp(this, 12));
        r.setChecked(checked);
        return r;
    }

    private void load() {
        if (loading) return;
        loading = true;
        new Thread(() -> {
            final String err = Store.fetch(getApplicationContext());
            runOnUiThread(() -> {
                loading = false;
                if (err != null) Toast.makeText(this, err, Toast.LENGTH_LONG).show();
                if (Store.feed(this) != null || Store.token(this) == null) build();
            });
        }).start();
    }

    private Class<?> typeOf(AppWidgetManager m) {
        AppWidgetProviderInfo info = m.getAppWidgetInfo(widgetId);
        if (info != null && info.provider != null) {
            String cn = info.provider.getClassName();
            for (Class<?> t : Widgets.TYPES) if (t.getName().equals(cn)) return t;
        }
        return GardeWidget.class;
    }
}
