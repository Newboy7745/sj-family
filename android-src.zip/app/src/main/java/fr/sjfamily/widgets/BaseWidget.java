package fr.sjfamily.widgets;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

/** Comportement commun : affichage immédiat depuis le cache puis actualisation en arrière-plan. */
public abstract class BaseWidget extends AppWidgetProvider {
    public static final String ACTION_REFRESH = "fr.sjfamily.widgets.REFRESH";
    public static final String ACTION_NAV = "fr.sjfamily.widgets.NAV";
    public static final String ACTION_TICK = "fr.sjfamily.widgets.TICK";

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) Widgets.render(context, manager, id, getClass());
        if (Store.token(context) == null || !Store.stale(context)) return;
        final Context app = context.getApplicationContext();
        final PendingResult pending = goAsync();
        new Thread(() -> {
            try {
                if (Store.fetch(app) == null) {
                    Widgets.updateAll(app);
                    Reminders.schedule(app);
                }
            } finally {
                pending.finish();
            }
        }).start();
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_TICK.equals(intent.getAction())) { Widgets.updateAll(context); return; }
        if (ACTION_NAV.equals(intent.getAction())) {
            int id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
            int delta = intent.getIntExtra("delta", 0);
            if (id != AppWidgetManager.INVALID_APPWIDGET_ID) {
                Store.setOffset(context, id, delta == 0 ? 0 : Store.offset(context, id) + delta);
                Widgets.render(context, AppWidgetManager.getInstance(context), id, getClass());
            }
            return;
        }
        if (ACTION_REFRESH.equals(intent.getAction())) {
            final Context app = context.getApplicationContext();
            Widgets.refreshing(app, true);
            final PendingResult pending = goAsync();
            new Thread(() -> {
                String err = null;
                try {
                    err = Store.fetch(app);
                    Widgets.updateAll(app);
                    Reminders.schedule(app);
                } finally {
                    Widgets.refreshing(app, false);
                    final String msg = err != null ? "SJ Family : " + err : "SJ Family : planning à jour ✓" + Store.updateHint(app);
                    new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> android.widget.Toast.makeText(app, msg, android.widget.Toast.LENGTH_SHORT).show());
                    pending.finish();
                }
            }).start();
        }
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager, int id, Bundle options) {
        Widgets.render(context, manager, id, getClass());
    }

    @Override
    public void onDeleted(Context context, int[] ids) {
        for (int id : ids) Store.removeChild(context, id);
    }
}
