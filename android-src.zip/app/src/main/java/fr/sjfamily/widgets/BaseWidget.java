package fr.sjfamily.widgets;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

/** Comportement commun : affichage immédiat depuis le cache puis actualisation en arrière-plan. */
public abstract class BaseWidget extends AppWidgetProvider {
    public static final String ACTION_REFRESH = "fr.sjfamily.widgets.REFRESH";

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) Widgets.render(context, manager, id, getClass());
        if (Store.token(context) == null || !Store.stale(context)) return;
        final Context app = context.getApplicationContext();
        final PendingResult pending = goAsync();
        new Thread(() -> {
            try {
                if (Store.fetch(app) == null) {
                    Widgets.updateAll(app);
                    Reminders.schedule(app);
                }
            } finally {
                pending.finish();
            }
        }).start();
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_REFRESH.equals(intent.getAction())) {
            final Context app = context.getApplicationContext();
            final PendingResult pending = goAsync();
            new Thread(() -> {
                try {
                    Store.fetch(app);
                    Widgets.updateAll(app);
                    Reminders.schedule(app);
                } finally {
                    pending.finish();
                }
            }).start();
        }
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager, int id, Bundle options) {
        Widgets.render(context, manager, id, getClass());
    }

    @Override
    public void onDeleted(Context context, int[] ids) {
        for (int id : ids) Store.removeChild(context, id);
    }
}
