package fr.sjfamily.widgets;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;

/** Dessin des 4 widgets à partir du flux en cache (aucun accès réseau ici). */
final class Widgets {
    static final Class<?>[] TYPES = {GardeWidget.class, SemaineWidget.class, MoisWidget.class, ProgrammeWidget.class};
    static final int[] CELLS = {R.id.c0, R.id.c1, R.id.c2, R.id.c3, R.id.c4, R.id.c5, R.id.c6, R.id.c7, R.id.c8, R.id.c9, R.id.c10, R.id.c11, R.id.c12, R.id.c13, R.id.c14, R.id.c15, R.id.c16, R.id.c17, R.id.c18, R.id.c19, R.id.c20, R.id.c21, R.id.c22, R.id.c23, R.id.c24, R.id.c25, R.id.c26, R.id.c27, R.id.c28, R.id.c29, R.id.c30, R.id.c31, R.id.c32, R.id.c33, R.id.c34, R.id.c35, R.id.c36, R.id.c37, R.id.c38, R.id.c39, R.id.c40, R.id.c41};
    static final int[] ROWS = {R.id.r0, R.id.r1, R.id.r2, R.id.r3, R.id.r4, R.id.r5};
    static final int[] WEEK = {R.id.w0, R.id.w1, R.id.w2, R.id.w3, R.id.w4, R.id.w5, R.id.w6};
    static final int[] LINES = {R.id.l0, R.id.l1, R.id.l2, R.id.l3, R.id.l4, R.id.l5};
    static final int INK = 0xFF13233A;

    private Widgets() { }

    static void updateAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (Class<?> t : TYPES) {
            int[] ids = m.getAppWidgetIds(new ComponentName(c, t));
            for (int id : ids) render(c, m, id, t);
        }
    }

    static int count(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int n = 0;
        for (Class<?> t : TYPES) n += m.getAppWidgetIds(new ComponentName(c, t)).length;
        return n;
    }

    static void render(Context c, AppWidgetManager m, int id, Class<?> type) {
        RemoteViews v;
        Feed f = Store.feed(c);
        try {
            if (f == null || f.children().isEmpty()) {
                v = empty(c, Store.token(c) == null
                        ? "Touchez ici pour connecter SJ Widgets à votre cercle SJ Family."
                        : "Chargement du planning… Touchez ici si rien ne s'affiche.");
            } else {
                List<JSONObject> kids = f.kids(Store.child(c, id));
                if (type == SemaineWidget.class) v = semaine(c, f, kids);
                else if (type == MoisWidget.class) v = mois(c, f, kids);
                else if (type == ProgrammeWidget.class) v = programme(c, f, kids);
                else v = garde(c, f, kids);
                v.setOnClickPendingIntent(R.id.root, openApp(c, f.app + "#/agenda"));
                Intent r = new Intent(c, type).setAction(BaseWidget.ACTION_REFRESH);
                v.setOnClickPendingIntent(R.id.refresh, PendingIntent.getBroadcast(c, 9000 + id, r,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            }
        } catch (Exception e) {
            v = empty(c, "Erreur d'affichage. Touchez pour actualiser.");
        }
        m.updateAppWidget(id, v);
    }

    static RemoteViews empty(Context c, String msg) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_empty);
        v.setTextViewText(R.id.msg, msg);
        Intent i = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        v.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(c, 1, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        return v;
    }

    static PendingIntent openApp(Context c, String url) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(c, 2, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static String nextText(Feed f, JSONObject h, LocalDate today) {
        LocalDateTime at = Feed.at(h);
        String place = h.optString("p", "");
        return "🔁 " + Fmt.cap(Fmt.rel(at.toLocalDate(), today)) + " " + Fmt.time(h.optString("t"))
                + " → " + f.pShort(h.optString("to")) + (place.isEmpty() ? "" : " (" + place + ")");
    }

    private static String eventText(JSONObject e, LocalDate today) {
        LocalDate d = LocalDate.parse(e.optString("d"));
        String t = e.optString("t", "");
        return e.optString("i", "📌") + " " + Fmt.cap(Fmt.rel(d, today)) + (t.isEmpty() ? "" : " " + Fmt.time(t)) + " · " + e.optString("n");
    }

    // ───────────── Garde du jour (2×2)
    static RemoteViews garde(Context c, Feed f, List<JSONObject> kids) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_garde);
        LocalDateTime now = LocalDateTime.now();
        LocalDate today = now.toLocalDate();
        Set<String> ids = Feed.ids(kids);
        String who = kids.isEmpty() ? null : f.presence(kids.get(0), now);
        boolean split = false;
        for (JSONObject k : kids) if (!Objects.equals(f.presence(k, now), who)) split = true;
        v.setTextViewText(R.id.kid, f.label(kids).toUpperCase(Locale.FRANCE));
        if (split) {
            SpannableStringBuilder b = new SpannableStringBuilder();
            for (JSONObject k : kids) {
                String p = f.presence(k, now);
                if (b.length() > 0) b.append("\n");
                b.append(k.optString("name")).append(" : ").append(p == null ? "—" : f.pShort(p));
            }
            v.setTextViewText(R.id.who, b);
            v.setTextViewTextSize(R.id.who, android.util.TypedValue.COMPLEX_UNIT_SP, 14);
            v.setInt(R.id.swatch, "setBackgroundColor", 0x33FFFFFF);
        } else {
            v.setTextViewText(R.id.who, who == null ? "—" : f.pShort(who));
            v.setTextViewTextSize(R.id.who, android.util.TypedValue.COMPLEX_UNIT_SP, 26);
            v.setInt(R.id.swatch, "setBackgroundColor", who == null ? 0x33FFFFFF : f.pColor(who));
        }
        List<JSONObject> hs = f.nextHandovers(ids, now, 1);
        if (hs.isEmpty()) {
            v.setTextViewText(R.id.next, "Aucun relais prévu");
            v.setTextViewText(R.id.count, "");
        } else {
            JSONObject h = hs.get(0);
            v.setTextViewText(R.id.next, nextText(f, h, today));
            v.setTextViewText(R.id.count, Fmt.countdown(now, Feed.at(h)));
        }
        return v;
    }

    // ───────────── Semaine (4×2)
    static RemoteViews semaine(Context c, Feed f, List<JSONObject> kids) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_semaine);
        LocalDateTime now = LocalDateTime.now();
        LocalDate today = now.toLocalDate();
        Set<String> ids = Feed.ids(kids);
        JSONObject k0 = kids.get(0);
        String who = f.presence(k0, now);
        v.setTextViewText(R.id.kid, (f.label(kids) + " · semaine").toUpperCase(Locale.FRANCE));
        v.setTextViewText(R.id.who, who == null ? "" : "Chez " + f.pShort(who));
        LocalDate mon = today.minusDays(today.getDayOfWeek().getValue() - 1);
        for (int i = 0; i < 7; i++) {
            LocalDate d = mon.plusDays(i);
            char code = k0 == null ? '.' : f.code(k0, d);
            String txt = Fmt.JL[i] + "\n" + d.getDayOfMonth() + (f.hasHandover(ids, d) ? "\n🔁" : "\n ");
            SpannableString s = new SpannableString(txt);
            s.setSpan(new RelativeSizeSpan(0.75f), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (d.equals(today)) {
                s.setSpan(new StyleSpan(Typeface.BOLD), 0, txt.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                s.setSpan(new UnderlineSpan(), 2, 2 + String.valueOf(d.getDayOfMonth()).length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            v.setTextViewText(WEEK[i], s);
            v.setInt(WEEK[i], "setBackgroundColor", f.colorFor(code));
            v.setTextColor(WEEK[i], INK);
        }
        List<JSONObject> hs = f.nextHandovers(ids, now, 1);
        v.setTextViewText(R.id.next, hs.isEmpty() ? "Aucun relais prévu" : nextText(f, hs.get(0), today) + " · " + Fmt.countdown(now, Feed.at(hs.get(0))));
        List<JSONObject> ev = f.events(ids, today, 1);
        if (ev.isEmpty()) v.setViewVisibility(R.id.event, View.GONE);
        else {
            v.setViewVisibility(R.id.event, View.VISIBLE);
            v.setTextViewText(R.id.event, eventText(ev.get(0), today));
        }
        return v;
    }

    // ───────────── Mois (4×4)
    static RemoteViews mois(Context c, Feed f, List<JSONObject> kids) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_mois);
        LocalDateTime now = LocalDateTime.now();
        LocalDate today = now.toLocalDate();
        Set<String> ids = Feed.ids(kids);
        JSONObject k0 = kids.get(0);
        String who = f.presence(k0, now);
        v.setTextViewText(R.id.title, Fmt.month(today) + " · " + f.label(kids));
        v.setTextViewText(R.id.who, who == null ? "" : "Chez " + f.pShort(who));
        LocalDate first = today.withDayOfMonth(1);
        int offset = first.getDayOfWeek().getValue() - 1;
        int days = today.lengthOfMonth();
        int weeks = (offset + days + 6) / 7;
        LocalDate start = first.minusDays(offset);
        for (int r = 0; r < 6; r++) v.setViewVisibility(ROWS[r], r < weeks ? View.VISIBLE : View.GONE);
        for (int i = 0; i < 42; i++) {
            LocalDate d = start.plusDays(i);
            boolean in = d.getMonthValue() == today.getMonthValue();
            String n = String.valueOf(d.getDayOfMonth());
            SpannableString s = new SpannableString(n);
            if (in && f.off(d) != null) s.setSpan(new ForegroundColorSpan(0xFFC0392B), 0, n.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (d.equals(today)) {
                s.setSpan(new StyleSpan(Typeface.BOLD), 0, n.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                s.setSpan(new UnderlineSpan(), 0, n.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            v.setTextViewText(CELLS[i], s);
            v.setTextColor(CELLS[i], in ? INK : 0x66FFFFFF);
            v.setInt(CELLS[i], "setBackgroundColor", in ? f.colorFor(f.code(k0, d)) : 0x10FFFFFF);
        }
        SpannableStringBuilder lg = new SpannableStringBuilder();
        legend(lg, "■ ", f.pColor("A")); lg.append(f.pName("A")).append("   ");
        legend(lg, "■ ", f.pColor("B")); lg.append(f.pName("B")).append("   ");
        legend(lg, "■ ", Feed.lighten(f.pColor("B"), 0.55f)); lg.append("école");
        v.setTextViewText(R.id.legend, lg);
        List<JSONObject> hs = f.nextHandovers(ids, now, 1);
        v.setTextViewText(R.id.next, hs.isEmpty() ? "Aucun relais prévu" : nextText(f, hs.get(0), today) + " · " + Fmt.countdown(now, Feed.at(hs.get(0))));
        List<JSONObject> ev = f.events(ids, today, 1);
        if (ev.isEmpty()) v.setViewVisibility(R.id.event, View.GONE);
        else {
            v.setViewVisibility(R.id.event, View.VISIBLE);
            v.setTextViewText(R.id.event, eventText(ev.get(0), today));
        }
        return v;
    }

    private static void legend(SpannableStringBuilder b, String sq, int color) {
        int s = b.length();
        b.append(sq);
        b.setSpan(new ForegroundColorSpan(color), s, s + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    // ───────────── Programme (4×2 / 4×3)
    static RemoteViews programme(Context c, Feed f, List<JSONObject> kids) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_programme);
        LocalDateTime now = LocalDateTime.now();
        LocalDate today = now.toLocalDate();
        Set<String> ids = Feed.ids(kids);
        String who = f.presence(kids.get(0), now);
        v.setTextViewText(R.id.kid, ("Programme · " + f.label(kids)).toUpperCase(Locale.FRANCE));
        v.setTextViewText(R.id.who, who == null ? "" : "Chez " + f.pShort(who));
        java.util.ArrayList<String[]> items = new java.util.ArrayList<>();
        for (JSONObject h : f.nextHandovers(ids, now, 3)) {
            String key = h.optString("d") + h.optString("t");
            String kn = f.kidNames(h.optJSONArray("k"));
            items.add(new String[]{key, nextText(f, h, today).replace(" → ", " · " + kn + " → ")});
        }
        for (JSONObject e : f.events(ids, today, 6)) items.add(new String[]{e.optString("d") + (e.optString("t", "").isEmpty() ? "00:00" : e.optString("t")), eventText(e, today)});
        items.sort((a, b) -> a[0].compareTo(b[0]));
        java.util.ArrayList<String> lines = new java.util.ArrayList<>();
        for (String[] it : items) if (lines.size() < 5) lines.add(it[1]);
        for (JSONObject t : f.tasks(ids, 2)) if (lines.size() < 6) {
            String d = t.optString("d", "");
            lines.add("✅ " + t.optString("n") + (d.isEmpty() ? "" : " · " + Fmt.rel(LocalDate.parse(d), today)));
        }
        JSONObject note = f.lastNote(ids);
        if (note != null && lines.size() < 6) lines.add("📒 " + note.optString("by") + " : " + note.optString("x"));
        if (lines.isEmpty()) lines.add("Rien de prévu pour le moment 🙂");
        for (int i = 0; i < LINES.length; i++) {
            if (i < lines.size()) {
                v.setViewVisibility(LINES[i], View.VISIBLE);
                v.setTextViewText(LINES[i], lines.get(i));
            } else v.setViewVisibility(LINES[i], View.GONE);
        }
        return v;
    }

    static int dummyColor() {
        return Color.WHITE;
    }
}
