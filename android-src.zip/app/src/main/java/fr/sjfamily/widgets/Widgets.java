package fr.sjfamily.widgets;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;

/** Dessin des 4 widgets à partir du flux en cache (aucun accès réseau ici). */
final class Widgets {
    static final Class<?>[] TYPES = {GardeWidget.class, SemaineWidget.class, MoisWidget.class, ProgrammeWidget.class, FullWidget.class};
    static final int[] FCELL = new int[42], FTEXT = new int[42], FDIAG = new int[42], FROWS = new int[6], FLINES = {R.id.fl0, R.id.fl1, R.id.fl2, R.id.fl3};
    static {
        int[] fc = {R.id.f0, R.id.f1, R.id.f2, R.id.f3, R.id.f4, R.id.f5, R.id.f6, R.id.f7, R.id.f8, R.id.f9, R.id.f10, R.id.f11, R.id.f12, R.id.f13, R.id.f14, R.id.f15, R.id.f16, R.id.f17, R.id.f18, R.id.f19, R.id.f20, R.id.f21, R.id.f22, R.id.f23, R.id.f24, R.id.f25, R.id.f26, R.id.f27, R.id.f28, R.id.f29, R.id.f30, R.id.f31, R.id.f32, R.id.f33, R.id.f34, R.id.f35, R.id.f36, R.id.f37, R.id.f38, R.id.f39, R.id.f40, R.id.f41};
        int[] ft = {R.id.ft0, R.id.ft1, R.id.ft2, R.id.ft3, R.id.ft4, R.id.ft5, R.id.ft6, R.id.ft7, R.id.ft8, R.id.ft9, R.id.ft10, R.id.ft11, R.id.ft12, R.id.ft13, R.id.ft14, R.id.ft15, R.id.ft16, R.id.ft17, R.id.ft18, R.id.ft19, R.id.ft20, R.id.ft21, R.id.ft22, R.id.ft23, R.id.ft24, R.id.ft25, R.id.ft26, R.id.ft27, R.id.ft28, R.id.ft29, R.id.ft30, R.id.ft31, R.id.ft32, R.id.ft33, R.id.ft34, R.id.ft35, R.id.ft36, R.id.ft37, R.id.ft38, R.id.ft39, R.id.ft40, R.id.ft41};
        int[] fx = {R.id.fx0, R.id.fx1, R.id.fx2, R.id.fx3, R.id.fx4, R.id.fx5, R.id.fx6, R.id.fx7, R.id.fx8, R.id.fx9, R.id.fx10, R.id.fx11, R.id.fx12, R.id.fx13, R.id.fx14, R.id.fx15, R.id.fx16, R.id.fx17, R.id.fx18, R.id.fx19, R.id.fx20, R.id.fx21, R.id.fx22, R.id.fx23, R.id.fx24, R.id.fx25, R.id.fx26, R.id.fx27, R.id.fx28, R.id.fx29, R.id.fx30, R.id.fx31, R.id.fx32, R.id.fx33, R.id.fx34, R.id.fx35, R.id.fx36, R.id.fx37, R.id.fx38, R.id.fx39, R.id.fx40, R.id.fx41};
        int[] fr = {R.id.fr0, R.id.fr1, R.id.fr2, R.id.fr3, R.id.fr4, R.id.fr5};
        System.arraycopy(fc, 0, FCELL, 0, 42); System.arraycopy(ft, 0, FTEXT, 0, 42); System.arraycopy(fx, 0, FDIAG, 0, 42); System.arraycopy(fr, 0, FROWS, 0, 6);
    }
    static final int[] CELLS = {R.id.c0, R.id.c1, R.id.c2, R.id.c3, R.id.c4, R.id.c5, R.id.c6, R.id.c7, R.id.c8, R.id.c9, R.id.c10, R.id.c11, R.id.c12, R.id.c13, R.id.c14, R.id.c15, R.id.c16, R.id.c17, R.id.c18, R.id.c19, R.id.c20, R.id.c21, R.id.c22, R.id.c23, R.id.c24, R.id.c25, R.id.c26, R.id.c27, R.id.c28, R.id.c29, R.id.c30, R.id.c31, R.id.c32, R.id.c33, R.id.c34, R.id.c35, R.id.c36, R.id.c37, R.id.c38, R.id.c39, R.id.c40, R.id.c41};
    static final int[] ROWS = {R.id.r0, R.id.r1, R.id.r2, R.id.r3, R.id.r4, R.id.r5};
    static final int[] TEXTS = {R.id.t0, R.id.t1, R.id.t2, R.id.t3, R.id.t4, R.id.t5, R.id.t6, R.id.t7, R.id.t8, R.id.t9, R.id.t10, R.id.t11, R.id.t12, R.id.t13, R.id.t14, R.id.t15, R.id.t16, R.id.t17, R.id.t18, R.id.t19, R.id.t20, R.id.t21, R.id.t22, R.id.t23, R.id.t24, R.id.t25, R.id.t26, R.id.t27, R.id.t28, R.id.t29, R.id.t30, R.id.t31, R.id.t32, R.id.t33, R.id.t34, R.id.t35, R.id.t36, R.id.t37, R.id.t38, R.id.t39, R.id.t40, R.id.t41};
    static final int[] DIAG = {R.id.x0, R.id.x1, R.id.x2, R.id.x3, R.id.x4, R.id.x5, R.id.x6, R.id.x7, R.id.x8, R.id.x9, R.id.x10, R.id.x11, R.id.x12, R.id.x13, R.id.x14, R.id.x15, R.id.x16, R.id.x17, R.id.x18, R.id.x19, R.id.x20, R.id.x21, R.id.x22, R.id.x23, R.id.x24, R.id.x25, R.id.x26, R.id.x27, R.id.x28, R.id.x29, R.id.x30, R.id.x31, R.id.x32, R.id.x33, R.id.x34, R.id.x35, R.id.x36, R.id.x37, R.id.x38, R.id.x39, R.id.x40, R.id.x41};
    static final int[] WTEXT = {R.id.wt0, R.id.wt1, R.id.wt2, R.id.wt3, R.id.wt4, R.id.wt5, R.id.wt6};
    static final int[] WDIAG = {R.id.wx0, R.id.wx1, R.id.wx2, R.id.wx3, R.id.wx4, R.id.wx5, R.id.wx6};
    static final int[] WEEK = {R.id.w0, R.id.w1, R.id.w2, R.id.w3, R.id.w4, R.id.w5, R.id.w6};
    static final int[] LINES = {R.id.l0, R.id.l1, R.id.l2, R.id.l3, R.id.l4, R.id.l5};
    static final int INK = 0xFF13233A;

    private Widgets() { }

    static void updateAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (Class<?> t : TYPES) {
            int[] ids = m.getAppWidgetIds(new ComponentName(c, t));
            for (int id : ids) render(c, m, id, t);
        }
    }

    /** Taille réelle donnée par l'écran d'accueil à chaque widget (diagnostic de largeur) */
    static String sizes(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        android.util.DisplayMetrics dm = c.getResources().getDisplayMetrics();
        StringBuilder b = new StringBuilder();
        String[] names = {"Garde", "Semaine", "Mois", "Programme", "Pleine page"};
        for (int k = 0; k < TYPES.length; k++) {
            for (int id : m.getAppWidgetIds(new ComponentName(c, TYPES[k]))) {
                android.os.Bundle o = m.getAppWidgetOptions(id);
                int w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH), w2 = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH), hh = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT), hh2 = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT);
                b.append("\n· ").append(k < names.length ? names[k] : TYPES[k].getSimpleName()).append(" : ").append(w).append('–').append(w2)
                        .append(" × ").append(hh).append('–').append(hh2).append(" dp");
            }
        }
        if (b.length() == 0) return "";
        android.graphics.Rect pad = android.appwidget.AppWidgetHostView.getDefaultPaddingForWidget(c, new ComponentName(c, FullWidget.class), null);
        return b.append("\nÉcran : ").append(Math.round(dm.widthPixels / dm.density)).append(" dp · marge système : ")
                .append(Math.round(pad.left / dm.density)).append(" dp").toString();
    }

    static int count(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int n = 0;
        for (Class<?> t : TYPES) n += m.getAppWidgetIds(new ComponentName(c, t)).length;
        return n;
    }

    static void render(Context c, AppWidgetManager m, int id, Class<?> type) {
        RemoteViews v;
        Feed f = Store.feed(c);
        try {
            if (f == null || f.children().isEmpty()) {
                v = empty(c, Store.token(c) == null
                        ? "Touchez ici pour connecter SJ Widgets à votre cercle SJ Family."
                        : "Chargement du planning… Touchez ici si rien ne s'affiche.");
            } else {
                List<JSONObject> kids = f.kids(Store.child(c, id));
                int off = Store.offset(c, id);
                if (type == SemaineWidget.class) v = semaine(c, f, kids, off, id);
                else if (type == MoisWidget.class) v = mois(c, f, kids, off, id);
                else if (type == FullWidget.class) v = full(c, f, kids, off, id);
                else if (type == ProgrammeWidget.class) v = programme(c, f, kids);
                else v = garde(c, f, kids, off);
                if (type != ProgrammeWidget.class) {
                    v.setOnClickPendingIntent(R.id.prev, nav(c, type, id, -1));
                    v.setOnClickPendingIntent(R.id.next_btn, nav(c, type, id, 1));
                    v.setOnClickPendingIntent(type == MoisWidget.class || type == FullWidget.class ? R.id.title : R.id.kid, nav(c, type, id, 0));
                    if (type == FullWidget.class) v.setOnClickPendingIntent(R.id.kid, nav(c, type, id, 0));
                }
                v.setOnClickPendingIntent(android.R.id.background, openApp(c, f.app + "#/agenda"));
                Intent r = new Intent(c, type).setAction(BaseWidget.ACTION_REFRESH);
                v.setOnClickPendingIntent(R.id.refresh, PendingIntent.getBroadcast(c, 9000 + id, r,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
                v.setInt(R.id.refresh, "setImageAlpha", busy ? 60 : 255);
            }
        } catch (Exception e) {
            v = empty(c, "Erreur d'affichage. Touchez pour actualiser.");
        }
        m.updateAppWidget(id, responsive(c, m, id, v));
    }

    /**
     * Android 12+ : mise en page « adaptative » (une taille déclarée) pour que l'écran d'accueil
     * affiche le widget à sa taille réelle au lieu de le réduire.
     */
    static RemoteViews responsive(Context c, AppWidgetManager m, int id, RemoteViews v) {
        if (android.os.Build.VERSION.SDK_INT < 31) return v;
        try {
            java.util.Map<android.util.SizeF, RemoteViews> map = new java.util.HashMap<>();
            map.put(new android.util.SizeF(100f, 100f), v); // une seule mise en page, utilisée à toutes les tailles
            return new RemoteViews(map);
        } catch (Exception e) {
            return v;
        }
    }

    /** Pendant l'actualisation : le bouton ⟳ s'estompe tout de suite (retour visuel immédiat) */
    static volatile boolean busy = false;

    static void refreshing(Context c, boolean on) {
        busy = on;
        updateAll(c);
    }

    /** Bouton ‹ (delta -1), › (+1) ou retour à aujourd'hui (0) */
    static PendingIntent nav(Context c, Class<?> type, int id, int delta) {
        Intent i = new Intent(c, type).setAction(BaseWidget.ACTION_NAV)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id).putExtra("delta", delta);
        return PendingIntent.getBroadcast(c, id * 10 + (delta < 0 ? 1 : delta > 0 ? 2 : 3), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Tous les relais du jour (matin, mi-journée, soir) avec l'heure, le parent qui récupère et le lieu */
    private static String relaisText(Feed f, JSONObject child, LocalDate d, boolean withDay, LocalDate today) {
        StringBuilder b = new StringBuilder();
        for (JSONObject h : f.handoversOn(child, d)) {
            if (b.length() > 0) b.append(" · ");
            String t2 = h.optString("t2", ""), pl = Feed.placeShort(h);
            b.append(Fmt.time(h.optString("t"))).append(t2.isEmpty() ? "" : "–" + Fmt.time(t2)).append(" → ").append(f.pShort(h.optString("to")))
                    .append(pl.isEmpty() ? "" : " (" + pl + ")");
        }
        if (b.length() == 0) return "";
        return "🔁 " + (withDay ? Fmt.cap(Fmt.rel(d, today)) + " " : "") + b;
    }

    static RemoteViews empty(Context c, String msg) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_empty);
        v.setTextViewText(R.id.msg, msg);
        Intent i = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        v.setOnClickPendingIntent(android.R.id.background, PendingIntent.getActivity(c, 1, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        return v;
    }

    static PendingIntent openApp(Context c, String url) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(c, 2, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Toucher une case : l'application s'ouvre sur ce jour dans l'agenda */
    static PendingIntent openDay(Context c, Feed f, LocalDate d, int req) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(f.app + "#/agenda?d=" + d)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Compte à rebours qui avance tout seul : « dans 1 j 21:12:33 » (jours + heures:minutes:secondes) */
    static void countdown(Context c, RemoteViews v, LocalDateTime now, LocalDateTime at) {
        if (at == null || !at.isAfter(now)) { v.setViewVisibility(R.id.chrono, View.GONE); return; }
        long ms = java.time.Duration.between(now, at).toMillis();
        long days = ms / 86400000L;
        long rest = ms - days * 86400000L;
        v.setChronometer(R.id.chrono, android.os.SystemClock.elapsedRealtime() + rest, days > 0 ? "dans " + days + " j %s" : "dans %s", true);
        v.setChronometerCountDown(R.id.chrono, true);
        v.setViewVisibility(R.id.chrono, View.VISIBLE);
        if (days > 0) scheduleTick(c, System.currentTimeMillis() + rest + 1500);
    }

    /** Redessine les widgets au moment où le nombre de jours du compte à rebours change */
    static void scheduleTick(Context c, long when) {
        try {
            android.app.AlarmManager am = c.getSystemService(android.app.AlarmManager.class);
            Intent i = new Intent(c, GardeWidget.class).setAction(BaseWidget.ACTION_TICK);
            PendingIntent pi = PendingIntent.getBroadcast(c, 7777, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.setWindow(android.app.AlarmManager.RTC, when, 60000L, pi);
        } catch (Exception e) { /* facultatif */ }
    }

    /** Couleur d'un jour passé : celle du parent, légèrement atténuée */
    static int past(int color) { return Feed.mix(color, 0xFF5A6B80, 0.2f); }

    private static String nextText(Feed f, JSONObject h, LocalDate today) {
        LocalDateTime at = Feed.at(h);
        String place = h.optString("dp", "").isEmpty() ? h.optString("p", "") : h.optString("dp", "");
        String t2 = h.optString("t2", "");
        return "🔁 " + Fmt.cap(Fmt.rel(at.toLocalDate(), today)) + " " + Fmt.time(h.optString("t")) + (t2.isEmpty() ? "" : "–" + Fmt.time(t2))
                + " → " + f.pShort(h.optString("to")) + (place.isEmpty() ? "" : " (" + place + ")");
    }

    private static String eventText(JSONObject e, LocalDate today) {
        LocalDate d = LocalDate.parse(e.optString("d"));
        String t = e.optString("t", "");
        return e.optString("i", "📌") + " " + Fmt.cap(Fmt.rel(d, today)) + (t.isEmpty() ? "" : " " + Fmt.time(t)) + " · " + e.optString("n");
    }

    // ───────────── Garde du jour (2×2) — ‹ › change de jour
    static RemoteViews garde(Context c, Feed f, List<JSONObject> kids, int off) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_garde);
        LocalDateTime now = LocalDateTime.now();
        LocalDate today = now.toLocalDate();
        Set<String> ids = Feed.ids(kids);
        v.setTextViewText(R.id.kid, f.label(kids).toUpperCase(Locale.FRANCE));
        if (off == 0) {
            String who = kids.isEmpty() ? null : f.presence(kids.get(0), now);
            boolean split = false;
            for (JSONObject k : kids) if (!Objects.equals(f.presence(k, now), who)) split = true;
            v.setTextViewText(R.id.label, "Actuellement chez");
            if (split) {
                SpannableStringBuilder b = new SpannableStringBuilder();
                for (JSONObject k : kids) {
                    String p = f.presence(k, now);
                    if (b.length() > 0) b.append("\n");
                    b.append(k.optString("name")).append(" : ").append(p == null ? "—" : f.pShort(p));
                }
                v.setTextViewText(R.id.who, b);
                v.setTextViewTextSize(R.id.who, android.util.TypedValue.COMPLEX_UNIT_SP, 14);
                v.setInt(R.id.swatch, "setBackgroundColor", 0x33FFFFFF);
            } else {
                v.setTextViewText(R.id.who, who == null ? "—" : f.pShort(who));
                v.setTextViewTextSize(R.id.who, android.util.TypedValue.COMPLEX_UNIT_SP, 26);
                v.setInt(R.id.swatch, "setBackgroundColor", who == null ? 0x33FFFFFF : f.pColor(who));
            }
            List<JSONObject> hs = f.nextHandovers(ids, now, 1);
            if (hs.isEmpty()) {
                v.setTextViewText(R.id.next, "Aucun relais prévu");
                v.setTextViewText(R.id.count, "");
            } else {
                JSONObject h = hs.get(0);
                v.setTextViewText(R.id.next, nextText(f, h, today));
                v.setTextViewText(R.id.count, "");
                v.setViewVisibility(R.id.count, View.GONE);
                countdown(c, v, now, Feed.at(h));
            }
            return v;
        }
        // autre jour
        LocalDate day = today.plusDays(off);
        v.setTextViewText(R.id.label, Fmt.cap(Fmt.rel(day, today)) + (off > 1 && off < 7 ? " " + day.getDayOfMonth() + " " + Fmt.MOC[day.getMonthValue() - 1] : "") + " :");
        boolean split = false;
        char c0 = kids.isEmpty() ? '.' : f.code(kids.get(0), day);
        for (JSONObject k : kids) if (f.code(k, day) != c0) split = true;
        if (split) {
            SpannableStringBuilder b = new SpannableStringBuilder();
            for (JSONObject k : kids) {
                if (b.length() > 0) b.append("\n");
                b.append(k.optString("name")).append(" : ").append(dayWho(f, f.code(k, day)));
            }
            v.setTextViewText(R.id.who, b);
            v.setTextViewTextSize(R.id.who, android.util.TypedValue.COMPLEX_UNIT_SP, 14);
            v.setInt(R.id.swatch, "setBackgroundColor", 0x33FFFFFF);
        } else {
            v.setTextViewText(R.id.who, dayWho(f, c0));
            v.setTextViewTextSize(R.id.who, android.util.TypedValue.COMPLEX_UNIT_SP, c0 == 'X' || c0 == 'Y' ? 16 : 26);
            v.setInt(R.id.swatch, "setBackgroundColor", f.colorFor(c0));
        }
        String r = kids.isEmpty() ? "" : relaisText(f, kids.get(0), day, false, today);
        v.setTextViewText(R.id.next, r.isEmpty() ? "Pas de relais ce jour" : r);
        v.setViewVisibility(R.id.count, View.VISIBLE);
        v.setViewVisibility(R.id.chrono, View.GONE);
        v.setTextViewText(R.id.count, (off > 0 ? "dans " + off + " j" : "il y a " + (-off) + " j") + " · touchez le titre pour revenir");
        return v;
    }

    private static String dayWho(Feed f, char c) {
        if (c == 'X') return f.pShort("A") + " puis " + f.pShort("B");
        if (c == 'Y') return f.pShort("B") + " puis " + f.pShort("A");
        String p = Feed.first(c);
        return p == null ? "—" : f.pShort(p) + (c == 'a' || c == 'b' ? " (école)" : "");
    }

    // ───────────── Semaine (4×2)
    static RemoteViews semaine(Context c, Feed f, List<JSONObject> kids, int off, int id) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_semaine);
        LocalDateTime now = LocalDateTime.now();
        LocalDate today = now.toLocalDate();
        Set<String> ids = Feed.ids(kids);
        JSONObject k0 = kids.get(0);
        String who = f.presence(k0, now);
        LocalDate mon = today.minusDays(today.getDayOfWeek().getValue() - 1).plusWeeks(off);
        v.setTextViewText(R.id.kid, (off == 0 ? f.label(kids) + " · semaine" : "Semaine du " + mon.getDayOfMonth() + " " + Fmt.MOC[mon.getMonthValue() - 1] + " · " + f.label(kids)).toUpperCase(Locale.FRANCE));
        v.setTextViewText(R.id.who, off != 0 || who == null ? "" : "Chez " + f.pShort(who));
        for (int i = 0; i < 7; i++) {
            LocalDate d = mon.plusDays(i);
            char code = k0 == null ? '.' : f.code(k0, d);
            List<JSONObject> hd = k0 == null ? new java.util.ArrayList<>() : f.handoversOn(k0, d);
            String txt = Fmt.JL[i] + "\n" + d.getDayOfMonth() + (hd.isEmpty() ? "\n " : "\n🔁" + Fmt.time(hd.get(0).optString("t")) + (Feed.placeShort(hd.get(0)).isEmpty() ? "" : " " + Feed.placeShort(hd.get(0))));
            SpannableString s = new SpannableString(txt);
            s.setSpan(new RelativeSizeSpan(0.75f), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (d.equals(today)) {
                s.setSpan(new StyleSpan(Typeface.BOLD), 0, txt.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                s.setSpan(new UnderlineSpan(), 2, 2 + String.valueOf(d.getDayOfMonth()).length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            v.setTextViewText(WTEXT[i], s);
            v.setInt(WEEK[i], "setBackgroundColor", d.isBefore(today) ? past(f.colorFor(code)) : f.colorFor(code));
            v.setTextColor(WTEXT[i], d.isBefore(today) ? 0x9913233A : INK);
            v.setViewVisibility(WDIAG[i], d.isBefore(today) ? View.VISIBLE : View.GONE);
            v.setOnClickPendingIntent(WEEK[i], openDay(c, f, d, id * 100 + 60 + i));
        }
        if (off == 0) {
            List<JSONObject> hs = f.nextHandovers(ids, now, 1);
            v.setTextViewText(R.id.next, hs.isEmpty() ? "Aucun relais prévu" : nextText(f, hs.get(0), today));
            countdown(c, v, now, hs.isEmpty() ? null : Feed.at(hs.get(0)));
        } else {
            v.setViewVisibility(R.id.chrono, View.GONE);
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < 7 && k0 != null; i++) {
                String r = relaisText(f, k0, mon.plusDays(i), true, today);
                if (!r.isEmpty()) b.append(b.length() > 0 ? "  " : "").append(r);
            }
            v.setTextViewText(R.id.next, b.length() == 0 ? "Aucun relais cette semaine" : b.toString());
        }
        List<JSONObject> ev = f.events(ids, off == 0 ? today : mon, 1);
        if (!ev.isEmpty() && off != 0 && ev.get(0).optString("d").compareTo(mon.plusDays(6).toString()) > 0) ev.clear();
        if (ev.isEmpty()) v.setViewVisibility(R.id.event, View.GONE);
        else {
            v.setViewVisibility(R.id.event, View.VISIBLE);
            v.setTextViewText(R.id.event, eventText(ev.get(0), today));
        }
        return v;
    }

    // ───────────── Mois (4×4)
    static RemoteViews mois(Context c, Feed f, List<JSONObject> kids, int off, int id) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_mois);
        LocalDateTime now = LocalDateTime.now();
        LocalDate today = now.toLocalDate();
        Set<String> ids = Feed.ids(kids);
        JSONObject k0 = kids.get(0);
        String who = f.presence(k0, now);
        LocalDate first = today.withDayOfMonth(1).plusMonths(off);
        v.setTextViewText(R.id.title, Fmt.month(first) + " · " + f.label(kids));
        v.setTextViewText(R.id.who, off != 0 || who == null ? "" : "Chez " + f.pShort(who));
        int offset = first.getDayOfWeek().getValue() - 1;
        int days = first.lengthOfMonth();
        int weeks = (offset + days + 6) / 7;
        LocalDate start = first.minusDays(offset);
        for (int r = 0; r < 6; r++) v.setViewVisibility(ROWS[r], r < weeks ? View.VISIBLE : View.GONE);
        for (int i = 0; i < 42; i++) {
            LocalDate d = start.plusDays(i);
            boolean in = d.getMonthValue() == first.getMonthValue();
            String n = String.valueOf(d.getDayOfMonth());
            List<JSONObject> hd = in && !kids.isEmpty() ? f.handoversOn(kids.get(0), d) : new java.util.ArrayList<>();
            String tx = hd.isEmpty() ? n : n + "\n🔁" + Fmt.time(hd.get(0).optString("t"));
            SpannableString s = new SpannableString(tx);
            if (tx.length() > n.length()) s.setSpan(new RelativeSizeSpan(0.62f), n.length(), tx.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (in && f.off(d) != null) s.setSpan(new ForegroundColorSpan(0xFFC0392B), 0, n.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (d.equals(today)) {
                s.setSpan(new StyleSpan(Typeface.BOLD), 0, n.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                s.setSpan(new UnderlineSpan(), 0, n.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            boolean past = in && d.isBefore(today);
            v.setTextViewText(TEXTS[i], s);
            v.setTextColor(TEXTS[i], !in ? 0x66FFFFFF : past ? 0x9913233A : INK);
            int col = f.colorFor(f.code(k0, d));
            v.setInt(CELLS[i], "setBackgroundColor", !in ? 0x10FFFFFF : past ? past(col) : col);
            v.setViewVisibility(DIAG[i], past ? View.VISIBLE : View.GONE);
            v.setOnClickPendingIntent(CELLS[i], openDay(c, f, d, id * 100 + i));
        }
        SpannableStringBuilder lg = new SpannableStringBuilder();
        legend(lg, "■ ", f.pColor("A")); lg.append(f.pName("A")).append("   ");
        legend(lg, "■ ", f.pColor("B")); lg.append(f.pName("B")).append("   ");
        legend(lg, "■ ", Feed.lighten(f.pColor("B"), 0.55f)); lg.append("école");
        v.setTextViewText(R.id.legend, lg);
        if (off == 0) {
            List<JSONObject> hs = f.nextHandovers(ids, now, 1);
            v.setTextViewText(R.id.next, hs.isEmpty() ? "Aucun relais prévu" : nextText(f, hs.get(0), today));
            countdown(c, v, now, hs.isEmpty() ? null : Feed.at(hs.get(0)));
        } else {
            v.setViewVisibility(R.id.chrono, View.GONE);
            double ca = 0, cb = 0;
            for (int i = 0; i < days; i++) {
                char cc = f.code(k0, first.plusDays(i));
                if (cc == 'A') ca++; else if (cc == 'B') cb++; else if (cc == 'X' || cc == 'Y') { ca += 0.5; cb += 0.5; }
            }
            v.setTextViewText(R.id.next, "📊 " + f.pName("A") + " " + Fmt.num(ca) + " j · " + f.pName("B") + " " + Fmt.num(cb) + " j (comptés)");
        }
        List<JSONObject> ev = f.events(ids, off == 0 ? today : first, 1);
        if (!ev.isEmpty() && off != 0 && !ev.get(0).optString("d").startsWith(first.toString().substring(0, 7))) ev.clear();
        if (ev.isEmpty()) v.setViewVisibility(R.id.event, View.GONE);
        else {
            v.setViewVisibility(R.id.event, View.VISIBLE);
            v.setTextViewText(R.id.event, eventText(ev.get(0), today));
        }
        return v;
    }

    // ───────────── Pleine page (à étirer sur tout l'écran) — ‹ › change de mois, case = ce jour dans l'agenda
    static RemoteViews full(Context c, Feed f, List<JSONObject> kids, int off, int id) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_full);
        LocalDateTime now = LocalDateTime.now();
        LocalDate today = now.toLocalDate();
        Set<String> ids = Feed.ids(kids);
        JSONObject k0 = kids.get(0);
        LocalDate first = today.withDayOfMonth(1).plusMonths(off);
        v.setTextViewText(R.id.title, Fmt.month(first));
        v.setTextViewText(R.id.kid, f.label(kids));
        int offset = first.getDayOfWeek().getValue() - 1, days = first.lengthOfMonth(), weeks = (offset + days + 6) / 7;
        LocalDate start = first.minusDays(offset);
        if (off == 0) {
            String who = f.presence(k0, now);
            boolean split = false;
            for (JSONObject k : kids) if (!Objects.equals(f.presence(k, now), who)) split = true;
            if (split) {
                StringBuilder b = new StringBuilder();
                for (JSONObject k : kids) { String p = f.presence(k, now); b.append(b.length() > 0 ? " · " : "").append(k.optString("name")).append(" chez ").append(p == null ? "—" : f.pShort(p)); }
                v.setTextViewText(R.id.who, b.toString());
                v.setInt(R.id.swatch, "setBackgroundColor", 0x33FFFFFF);
            } else {
                v.setTextViewText(R.id.who, who == null ? "Pas de planning" : "Chez " + f.pName(who));
                v.setInt(R.id.swatch, "setBackgroundColor", who == null ? 0x33FFFFFF : f.pColor(who));
            }
            List<JSONObject> hs = f.nextHandovers(ids, now, 1);
            v.setTextViewText(R.id.next, hs.isEmpty() ? "Aucun relais prévu" : nextText(f, hs.get(0), today));
            countdown(c, v, now, hs.isEmpty() ? null : Feed.at(hs.get(0)));
        } else {
            double ca = 0, cb = 0;
            for (int i = 0; i < days; i++) { char cc = f.code(k0, first.plusDays(i)); if (cc == 'A') ca++; else if (cc == 'B') cb++; else if (cc == 'X' || cc == 'Y') { ca += 0.5; cb += 0.5; } }
            v.setTextViewText(R.id.who, "📊 " + f.pName("A") + " " + Fmt.num(ca) + " j · " + f.pName("B") + " " + Fmt.num(cb) + " j");
            v.setInt(R.id.swatch, "setBackgroundColor", 0x33FFFFFF);
            v.setTextViewText(R.id.next, "Touchez le titre pour revenir à aujourd'hui");
            v.setViewVisibility(R.id.chrono, View.GONE);
        }
        for (int r = 0; r < 6; r++) v.setViewVisibility(FROWS[r], r < weeks ? View.VISIBLE : View.GONE);
        for (int i = 0; i < 42; i++) {
            LocalDate d = start.plusDays(i);
            boolean in = d.getMonthValue() == first.getMonthValue(), past = in && d.isBefore(today);
            String n = String.valueOf(d.getDayOfMonth());
            String r = in ? relaisShort(f, k0, d) : "";
            boolean ev = in && !f.events(ids, d, 1).isEmpty() && f.events(ids, d, 1).get(0).optString("d").equals(d.toString());
            String txt = n + (r.isEmpty() && !ev ? "" : "\n" + r + (ev ? (r.isEmpty() ? "" : " ") + "•" : ""));
            SpannableString s = new SpannableString(txt);
            s.setSpan(new StyleSpan(Typeface.BOLD), 0, n.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (txt.length() > n.length()) s.setSpan(new RelativeSizeSpan(0.68f), n.length(), txt.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (in && f.off(d) != null) s.setSpan(new ForegroundColorSpan(0xFFC0392B), 0, n.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            if (d.equals(today)) s.setSpan(new UnderlineSpan(), 0, n.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            v.setTextViewText(FTEXT[i], s);
            v.setTextColor(FTEXT[i], !in ? 0x66FFFFFF : past ? 0x9913233A : INK);
            int col = f.colorFor(f.code(k0, d));
            v.setInt(FCELL[i], "setBackgroundColor", !in ? 0x10FFFFFF : past ? past(col) : col);
            v.setViewVisibility(FDIAG[i], past ? View.VISIBLE : View.GONE);
            v.setOnClickPendingIntent(FCELL[i], openDay(c, f, d, id * 100 + i));
        }
        SpannableStringBuilder lg = new SpannableStringBuilder();
        legend(lg, "■ ", f.pColor("A")); lg.append(f.pName("A")).append("   ");
        legend(lg, "■ ", f.pColor("B")); lg.append(f.pName("B")).append("   ");
        legend(lg, "■ ", Feed.lighten(f.pColor("B"), 0.55f)); lg.append("école  🔁 relais  • RDV");
        v.setTextViewText(R.id.legend, lg);
        java.util.ArrayList<String> lines = new java.util.ArrayList<>();
        if (off == 0) {
            for (JSONObject h : f.nextHandovers(ids, now, 2)) lines.add(nextText(f, h, today).replace(" → ", " · " + f.kidNames(h.optJSONArray("k")) + " → "));
            for (JSONObject e : f.events(ids, today, 2)) lines.add(eventText(e, today));
        } else {
            for (int i = 0; i < days && lines.size() < 4; i++) { String rr = relaisText(f, k0, first.plusDays(i), true, today); if (!rr.isEmpty()) lines.add(rr); }
        }
        for (int i = 0; i < FLINES.length; i++) {
            if (i < lines.size()) { v.setViewVisibility(FLINES[i], View.VISIBLE); v.setTextViewText(FLINES[i], lines.get(i)); }
            else v.setViewVisibility(FLINES[i], View.GONE);
        }
        return v;
    }

    /** « 🔁8h20 » + lieu (« École ») pour chaque relais du jour : matin, mi-journée ou soir */
    private static String relaisShort(Feed f, JSONObject child, LocalDate d) {
        StringBuilder b = new StringBuilder();
        for (JSONObject h : f.handoversOn(child, d)) {
            if (b.length() > 0) b.append("\n");
            String pl = Feed.placeShort(h);
            b.append("🔁").append(Fmt.time(h.optString("t"))).append(pl.isEmpty() ? "" : "\n" + pl);
        }
        return b.toString();
    }

    private static void legend(SpannableStringBuilder b, String sq, int color) {
        int s = b.length();
        b.append(sq);
        b.setSpan(new ForegroundColorSpan(color), s, s + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    // ───────────── Programme (4×2 / 4×3)
    static RemoteViews programme(Context c, Feed f, List<JSONObject> kids) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_programme);
        LocalDateTime now = LocalDateTime.now();
        LocalDate today = now.toLocalDate();
        Set<String> ids = Feed.ids(kids);
        String who = f.presence(kids.get(0), now);
        v.setTextViewText(R.id.kid, ("Programme · " + f.label(kids)).toUpperCase(Locale.FRANCE));
        v.setTextViewText(R.id.who, who == null ? "" : "Chez " + f.pShort(who));
        java.util.ArrayList<String[]> items = new java.util.ArrayList<>();
        for (JSONObject h : f.nextHandovers(ids, now, 3)) {
            String key = h.optString("d") + h.optString("t");
            String kn = f.kidNames(h.optJSONArray("k"));
            items.add(new String[]{key, nextText(f, h, today).replace(" → ", " · " + kn + " → ")});
        }
        for (JSONObject e : f.events(ids, today, 6)) items.add(new String[]{e.optString("d") + (e.optString("t", "").isEmpty() ? "00:00" : e.optString("t")), eventText(e, today)});
        items.sort((a, b) -> a[0].compareTo(b[0]));
        java.util.ArrayList<String> lines = new java.util.ArrayList<>();
        for (String[] it : items) if (lines.size() < 5) lines.add(it[1]);
        for (JSONObject t : f.tasks(ids, 2)) if (lines.size() < 6) {
            String d = t.optString("d", "");
            lines.add("✅ " + t.optString("n") + (d.isEmpty() ? "" : " · " + Fmt.rel(LocalDate.parse(d), today)));
        }
        JSONObject note = f.lastNote(ids);
        if (note != null && lines.size() < 6) lines.add("📒 " + note.optString("by") + " : " + note.optString("x"));
        if (lines.isEmpty()) lines.add("Rien de prévu pour le moment 🙂");
        for (int i = 0; i < LINES.length; i++) {
            if (i < lines.size()) {
                v.setViewVisibility(LINES[i], View.VISIBLE);
                v.setTextViewText(LINES[i], lines.get(i));
            } else v.setViewVisibility(LINES[i], View.GONE);
        }
        return v;
    }

    static int dummyColor() {
        return Color.WHITE;
    }
}
