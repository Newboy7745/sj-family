package fr.sjfamily.widgets;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/** Stockage local (jeton, flux, réglages) et téléchargement du flux. */
final class Store {
    static final String API = "https://firestore.googleapis.com/v1/projects/sj-family-dd337/databases/(default)/documents/widgets/";
    static final String KEY = "AIzaSyDlyQZ-O5Xuko-jtIvhJSzlncg1eL9Icdg";

    private Store() { }

    static SharedPreferences p(Context c) {
        return c.getSharedPreferences("sjf", Context.MODE_PRIVATE);
    }

    static String token(Context c) {
        String t = p(c).getString("token", null);
        return t == null || t.trim().isEmpty() ? null : t.trim();
    }

    static void setToken(Context c, String t) {
        p(c).edit().putString("token", t.trim()).remove("feed").putLong("feedAt", 0).apply();
    }

    static Feed feed(Context c) {
        String s = p(c).getString("feed", null);
        if (s == null) return null;
        try {
            return new Feed(s);
        } catch (Exception e) {
            return null;
        }
    }

    static long feedAt(Context c) {
        return p(c).getLong("feedAt", 0);
    }

    static boolean stale(Context c) {
        return System.currentTimeMillis() - feedAt(c) > 10 * 60 * 1000L;
    }

    /** Télécharge le flux ; renvoie null si tout va bien, sinon un message d'erreur. */
    static synchronized String fetch(Context c) {
        String t = token(c);
        if (t == null) return "Aucun code de connexion : ouvrez SJ Family › Widgets › Connecter.";
        HttpURLConnection con = null;
        try {
            URL u = new URL(API + URLEncoder.encode(t, "UTF-8") + "?key=" + KEY);
            con = (HttpURLConnection) u.openConnection();
            con.setConnectTimeout(15000);
            con.setReadTimeout(15000);
            int code = con.getResponseCode();
            String body = read(code >= 400 ? con.getErrorStream() : con.getInputStream());
            if (code == 404) return "Code inconnu : vérifiez le code dans SJ Family › Widgets.";
            if (code == 403) return "Accès refusé : les règles Firestore doivent être mises à jour.";
            if (code >= 400) return "Erreur du serveur (" + code + ").";
            JSONObject j = new JSONObject(body);
            String payload = j.getJSONObject("fields").getJSONObject("payload").getString("stringValue");
            new Feed(payload);
            p(c).edit().putString("feed", payload).putLong("feedAt", System.currentTimeMillis()).apply();
            return null;
        } catch (Exception e) {
            return "Pas de connexion internet (" + e.getClass().getSimpleName() + ").";
        } finally {
            if (con != null) con.disconnect();
        }
    }

    static String read(InputStream in) throws IOException {
        if (in == null) return "";
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        in.close();
        return b.toString("UTF-8");
    }

    static String child(Context c, int widgetId) {
        return p(c).getString("child_" + widgetId, "*");
    }

    static void setChild(Context c, int widgetId, String child) {
        p(c).edit().putString("child_" + widgetId, child).apply();
    }

    static void removeChild(Context c, int widgetId) {
        p(c).edit().remove("child_" + widgetId).remove("off_" + widgetId).remove("offAt_" + widgetId).apply();
    }

    /** Décalage affiché par un widget (jours, semaines ou mois) ; revient à aujourd'hui après 30 min. */
    static int offset(Context c, int widgetId) {
        long at = p(c).getLong("offAt_" + widgetId, 0);
        if (System.currentTimeMillis() - at > 30 * 60 * 1000L) return 0;
        return p(c).getInt("off_" + widgetId, 0);
    }

    static void setOffset(Context c, int widgetId, int off) {
        p(c).edit().putInt("off_" + widgetId, off).putLong("offAt_" + widgetId, System.currentTimeMillis()).apply();
    }

    /** Minutes avant le relais pour le rappel, -1 = désactivé. */
    static int remind(Context c) {
        return p(c).getInt("remind", 120);
    }

    static void setRemind(Context c, int v) {
        p(c).edit().putInt("remind", v).apply();
    }
}
