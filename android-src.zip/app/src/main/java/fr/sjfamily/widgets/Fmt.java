package fr.sjfamily.widgets;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

/** Mise en forme française des dates et heures. */
final class Fmt {
    static final String[] JL = {"L", "M", "M", "J", "V", "S", "D"};
    static final String[] JOURS = {"lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"};
    static final String[] JC = {"lun.", "mar.", "mer.", "jeu.", "ven.", "sam.", "dim."};
    static final String[] MOIS = {"janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"};
    static final String[] MOC = {"janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."};

    private Fmt() { }

    static String time(String t) {
        int m = Feed.toMin(t);
        int mm = m % 60;
        return (m / 60) + "h" + (mm == 0 ? "" : String.format(Locale.FRANCE, "%02d", mm));
    }

    static String cap(String s) {
        return s == null || s.isEmpty() ? "" : s.substring(0, 1).toUpperCase(Locale.FRANCE) + s.substring(1);
    }

    static String rel(LocalDate d, LocalDate today) {
        long k = ChronoUnit.DAYS.between(today, d);
        if (k == 0) return "aujourd'hui";
        if (k == 1) return "demain";
        int w = d.getDayOfWeek().getValue() - 1;
        if (k > 1 && k < 7) return JOURS[w];
        return JC[w] + " " + d.getDayOfMonth() + " " + MOC[d.getMonthValue() - 1];
    }

    static String countdown(LocalDateTime now, LocalDateTime at) {
        long min = Math.max(0, ChronoUnit.MINUTES.between(now, at));
        if (min < 60) return "dans " + min + " min";
        long d = min / 1440, h = (min % 1440) / 60, mm = min % 60;
        return d > 0 ? "dans " + d + " j " + h + " h" : "dans " + h + " h " + String.format(Locale.FRANCE, "%02d", mm);
    }

    static String num(double x) {
        long i = (long) Math.floor(x);
        return x - i > 0.01 ? (i == 0 ? "" : String.valueOf(i)) + "½" : String.valueOf(i);
    }

    static String month(LocalDate d) {
        return cap(MOIS[d.getMonthValue() - 1]) + " " + d.getYear();
    }
}
